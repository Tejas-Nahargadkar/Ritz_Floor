import ProfilePic from '../asset/Profile-pic.png'


export const items = [
  {
    status: "inactive",
    imgSrc:  ProfilePic,
    name: "Akash Singh",
    quote:
      "The Ritz floor is the leader of floor installation and repair in the country sed diam nonumy eirmod tempor invidunt ut labore and efficient strategy.",
  },
  {
    status: "inactive",
    imgSrc:  ProfilePic,
    name: "Akash Singh",
    quote:
      "The Ritz floor is the leader of floor installation and repair in the country sed diam nonumy eirmod tempor invidunt ut labore and efficient strategy.",
  },
  {
    status: "inactive",
    imgSrc:  ProfilePic,
    name: "Akash Singh",
    quote:
      "The Ritz floor is the leader of floor installation and repair in the country sed diam nonumy eirmod tempor invidunt ut labore and efficient strategy.",
  },
  {
    status: "inactive",
    imgSrc:  ProfilePic,
    name: "Akash Singh",
    quote:
      "The Ritz floor is the leader of floor installation and repair in the country sed diam nonumy eirmod tempor invidunt ut labore and efficient strategy.",
  },
  {
    status: "inactive",
    imgSrc:  ProfilePic,
    name: "Akash Singh",
    quote:
      "The Ritz floor is the leader of floor installation and repair in the country sed diam nonumy eirmod tempor invidunt ut labore and efficient strategy.",
  },
  {
    status: "inactive",
    imgSrc:  ProfilePic,
    name: "Akash Singh",
    quote:
      "The Ritz floor is the leader of floor installation and repair in the country sed diam nonumy eirmod tempor invidunt ut labore and efficient strategy.",
  },
  {
    status: "inactive",
    imgSrc:  ProfilePic,
    name: "Akash Singh",
    quote:
      "The Ritz floor is the leader of floor installation and repair in the country sed diam nonumy eirmod tempor invidunt ut labore and efficient strategy.",
  },
  {
    status: "inactive",
    imgSrc:  ProfilePic,
    name: "Akash Singh",
    quote:
      "The Ritz floor is the leader of floor installation and repair in the country sed diam nonumy eirmod tempor invidunt ut labore and efficient strategy.",
  },
  {
    status: "inactive",
    imgSrc:  ProfilePic,
    name: "Akash Singh",
    quote:
      "The Ritz floor is the leader of floor installation and repair in the country sed diam nonumy eirmod tempor invidunt ut labore and efficient strategy.",
  },
  {
    status: "inactive",
    imgSrc:  ProfilePic,
    name: "Akash Singh",
    quote:
      "The Ritz floor is the leader of floor installation and repair in the country sed diam nonumy eirmod tempor invidunt ut labore and efficient strategy.",
  },
  
];

export default items;
